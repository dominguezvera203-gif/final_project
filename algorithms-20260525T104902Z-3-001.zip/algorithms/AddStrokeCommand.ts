import { useCanvasStore } from '../state/useCanvasStore';
import { Layer, Stroke } from '../types';
import { Command } from './CommandManager';

export class AddStrokeCommand implements Command {
  constructor(private stroke: Stroke) {}

  execute() {
    useCanvasStore.getState().addStroke(this.stroke);
  }

  undo() {
    const { layers, activeLayer, setLayers } = useCanvasStore.getState();

    const updated: Layer[] = layers.map((layer) =>
      layer.id === activeLayer
        ? { ...layer, strokes: layer.strokes.slice(0, -1) }
        : layer
    );

    setLayers(updated);
  }
}