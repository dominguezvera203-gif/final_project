import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useCanvasStore } from '../state/useCanvasStore';

export default function Toolbar({ undo, redo }: any) {
  const {
    setColor,
    setStrokeWidth,
    setMode,
    clearCanvas,
    mode,
  } = useCanvasStore();

  return (
    <View style={styles.wrapper}>
      <View style={styles.container}>
        {/* MODE */}
        <TouchableOpacity onPress={() => setMode('draw')}>
          <Text style={[styles.btn, mode === 'draw' && styles.active]}>
            ✏️
          </Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setMode('erase')}>
          <Text style={[styles.btn, mode === 'erase' && styles.active]}>
            🧽
          </Text>
        </TouchableOpacity>

        {/* COLORS */}
        <TouchableOpacity onPress={() => setColor('#ffffff')}>
          <View style={[styles.color, { backgroundColor: '#fff' }]} />
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setColor('#ef4444')}>
          <View style={[styles.color, { backgroundColor: '#ef4444' }]} />
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setColor('#22c55e')}>
          <View style={[styles.color, { backgroundColor: '#22c55e' }]} />
        </TouchableOpacity>

        {/* SIZE */}
        <TouchableOpacity onPress={() => setStrokeWidth(2)}>
          <Text style={styles.btn}>•</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setStrokeWidth(5)}>
          <Text style={styles.btn}>●</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setStrokeWidth(10)}>
          <Text style={styles.btn}>⬤</Text>
        </TouchableOpacity>

        {/* ACTIONS */}
        <TouchableOpacity onPress={undo}>
          <Text style={styles.btn}>↩️</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={redo}>
          <Text style={styles.btn}>↪️</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={clearCanvas}>
          <Text style={styles.btn}>🧹</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: 'absolute',
    bottom: 20,
    left: 0,
    right: 0,
    alignItems: 'center',
  },
  container: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    backgroundColor: '#1e293b',
    padding: 10,
    borderRadius: 25,
    gap: 10,
  },
  btn: {
    color: '#38bdf8',
    fontSize: 18,
  },
  active: {
    color: '#facc15',
  },
  color: {
    width: 20,
    height: 20,
    borderRadius: 10,
  },
});