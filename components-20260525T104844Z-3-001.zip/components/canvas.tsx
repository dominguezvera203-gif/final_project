import React, { useRef } from 'react';
import { PanResponder, View } from 'react-native';
import Svg, { Path } from 'react-native-svg';
import { AddStrokeCommand } from '../algorithms/AddStrokeCommand';
import { CommandManager } from '../algorithms/CommandManager';
import { useCanvasStore } from '../state/useCanvasStore';
import { Point, Stroke } from '../types';

type Props = {
  manager: CommandManager;
};

export default function Canvas({ manager }: Props) {
  const points = useRef<Point[]>([]);
  const { layers, setLayers, color, strokeWidth, mode } = useCanvasStore();

  const buildPath = (pts: Point[]) => {
    if (pts.length < 2) return '';
    let d = `M ${pts[0].x} ${pts[0].y}`;
    for (let i = 1; i < pts.length; i++) {
      d += ` L ${pts[i].x} ${pts[i].y}`;
    }
    return d;
  };

  // 🔥 SIMPLE BUT WORKING ERASER (radius-based)
  const eraseAt = (x: number, y: number) => {
    const radius = 20;

    const updated = layers.map((layer) => ({
      ...layer,
      strokes: layer.strokes.filter((stroke) => {
        return !stroke.points.some((p) => {
          const dx = p.x - x;
          const dy = p.y - y;
          return Math.sqrt(dx * dx + dy * dy) < radius;
        });
      }),
    }));

    setLayers(updated);
  };

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,

      onPanResponderGrant: (e) => {
        const { locationX, locationY } = e.nativeEvent;

        if (mode === 'draw') {
          points.current = [{ x: locationX, y: locationY }];
        } else {
          eraseAt(locationX, locationY);
        }
      },

      onPanResponderMove: (e) => {
        const { locationX, locationY } = e.nativeEvent;

        if (mode === 'draw') {
          points.current.push({ x: locationX, y: locationY });
        } else {
          eraseAt(locationX, locationY);
        }
      },

      onPanResponderRelease: () => {
        if (mode === 'draw' && points.current.length > 1) {
          const stroke: Stroke = {
            points: points.current,
            color,
            width: strokeWidth,
          };

          manager.execute(new AddStrokeCommand(stroke));
          points.current = [];
        }
      },
    })
  ).current;

  return (
    <View style={{ flex: 1 }} {...panResponder.panHandlers}>
      <Svg style={{ flex: 1 }}>
        {layers.map((layer) =>
          layer.strokes.map((s, i) => (
            <Path
              key={i}
              d={buildPath(s.points)}
              stroke={s.color}
              strokeWidth={s.width}
              fill="none"
            />
          ))
        )}
      </Svg>
    </View>
  );
}