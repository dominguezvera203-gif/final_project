import { create } from 'zustand';
import { Layer, Stroke } from '../types';

type Mode = 'draw' | 'erase';

type CanvasState = {
  layers: Layer[];
  activeLayer: number;

  color: string;
  strokeWidth: number;
  mode: Mode;

  setColor: (color: string) => void;
  setStrokeWidth: (width: number) => void;
  setMode: (mode: Mode) => void;

  addStroke: (stroke: Stroke) => void;
  setLayers: (layers: Layer[]) => void;
  clearCanvas: () => void;
};

export const useCanvasStore = create<CanvasState>((set) => ({
  layers: [{ id: 1, strokes: [] }],
  activeLayer: 1,

  color: '#ffffff',
  strokeWidth: 4,
  mode: 'draw',

  setColor: (color) => set({ color }),
  setStrokeWidth: (width) => set({ strokeWidth: width }),
  setMode: (mode) => set({ mode }),

  addStroke: (stroke) =>
    set((state) => ({
      layers: state.layers.map((layer) =>
        layer.id === state.activeLayer
          ? { ...layer, strokes: [...layer.strokes, stroke] }
          : layer
      ),
    })),

  setLayers: (layers) => set({ layers }),

  clearCanvas: () =>
    set((state) => ({
      layers: state.layers.map((layer) => ({
        ...layer,
        strokes: [],
      })),
    })),
}));