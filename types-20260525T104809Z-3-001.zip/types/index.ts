export type Point = {
  x: number;
  y: number;
};

export type Stroke = {
  points: Point[];
  color: string;
  width: number;
  erased?: boolean;
};

export type Layer = {
  id: number;
  strokes: Stroke[];
};