import { useEffect, useRef } from 'react';
import { StyleSheet, View } from 'react-native';
import { CommandManager } from '../algorithms/CommandManager';
import Canvas from '../components/canvas';
import Toolbar from '../components/Toolbar';
import { useCanvasStore } from '../state/useCanvasStore';
import { loadCanvas, saveCanvas } from '../utils/storage';

export default function HomeScreen() {
  const manager = useRef(new CommandManager()).current;
  const { layers, setLayers } = useCanvasStore();

  useEffect(() => {
    const load = async () => {
      const data = await loadCanvas();
      if (data) setLayers(data);
    };
    load();
  }, []);

  useEffect(() => {
    saveCanvas(layers);
  }, [layers]);

  return (
    <View style={styles.container}>
      <Canvas manager={manager} />
      <Toolbar
        undo={() => manager.undo()}
        redo={() => manager.redo()}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
});