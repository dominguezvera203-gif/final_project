import AsyncStorage from '@react-native-async-storage/async-storage';
import { Layer } from '../types';

const KEY = 'CANVAS_DATA';

export const saveCanvas = async (layers: Layer[]) => {
  try {
    await AsyncStorage.setItem(KEY, JSON.stringify(layers));
  } catch (e) {
    console.log('Save error:', e);
  }
};

export const loadCanvas = async (): Promise<Layer[] | null> => {
  try {
    const data = await AsyncStorage.getItem(KEY);
    return data ? JSON.parse(data) : null;
  } catch (e) {
    console.log('Load error:', e);
    return null;
  }
};